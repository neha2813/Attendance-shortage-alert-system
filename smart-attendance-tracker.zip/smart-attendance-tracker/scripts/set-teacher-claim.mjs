import admin from 'firebase-admin';
import {readFileSync} from 'node:fs';
const serviceAccount=JSON.parse(readFileSync(process.env.GOOGLE_APPLICATION_CREDENTIALS,'utf8'));
admin.initializeApp({credential:admin.credential.cert(serviceAccount)});
const email=process.argv[2];if(!email)throw new Error('Usage: npm run set-teacher -- teacher@example.com');
const user=await admin.auth().getUserByEmail(email);
await admin.auth().setCustomUserClaims(user.uid,{teacher:true});
console.log(`Teacher claim enabled for ${email}. Ask the user to sign out and sign in again.`);
process.exit(0);
