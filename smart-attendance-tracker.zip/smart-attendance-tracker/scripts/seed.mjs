import admin from 'firebase-admin';
import {readFileSync} from 'node:fs';
const serviceAccount=JSON.parse(readFileSync(process.env.GOOGLE_APPLICATION_CREDENTIALS,'utf8'));
admin.initializeApp({credential:admin.credential.cert(serviceAccount)});
const db=admin.firestore();
const students=[
 ['S240566','Shanmukha','ECE','1st Year','1st Semester',[[40,35],[35,27],[42,32],[38,25],[30,26]]],
 ['S240622','Praneeth','ECE','1st Year','1st Semester',[[40,38],[35,31],[42,29],[38,34],[30,22]]],
 ['S240205','Mallika','ECE','1st Year','1st Semester',[[40,30],[35,29],[42,39],[38,32],[30,20]]],
 ['S240612','Sashi','ECE','1st Year','1st Semester',[[40,28],[35,24],[42,35],[38,27],[30,28]]],
 ['S240009','Neha','ECE','1st Year','1st Semester',[[40,37],[35,30],[42,36],[38,28],[30,27]]]
];
const names=['Mathematics','Physics','Programming in C','Electrical Circuits','Engineering Graphics'];
for(const [id,name,department,year,semester,values] of students){
 const users=await admin.auth().listUsers(1000);const authUser=users.users.find(u=>u.email===`${id.toLowerCase()}@students.demo`);
 if(!authUser)console.log(`Create Firebase Auth user ${id.toLowerCase()}@students.demo manually or with the Admin SDK before seeding; this seed script will not create passwords.`);
 const uid=authUser?.uid||`UNLINKED_${id}`;
 await db.collection('students').doc(id).set({studentId:id,name,department,year,semester,authUid:uid});
 for(let i=0;i<names.length;i++){const [total,attended]=values[i];const sid=names[i].toLowerCase().replace(/[^a-z0-9]+/g,'_');await db.collection('students').doc(id).collection('attendance').doc(sid).set({subjectName:names[i],total,attended,missed:total-attended});}
}
console.log('Sample student records seeded. Link real Firebase Auth UIDs before enabling student access.');
process.exit(0);
