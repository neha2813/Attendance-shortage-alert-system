# Smart Attendance Tracker

React + Firebase starter project for the AI-Based Attendance Shortage Alert System.

## Features
- Responsive student dashboard, overall and subject attendance, bar chart and shortage alerts.
- Correct `ceil((0.75 * total - attended) / 0.25)` calculation for consecutive present classes needed to reach 75%.
- Firebase Authentication for real student/teacher accounts.
- Cloud Functions enforce student ownership and teacher custom claims.
- Firestore transaction prevents duplicate records for a student + subject + class date.
- Gemini attendance assistant receives only the signed-in student's database attendance data.
- Sample records for five students.

## Important security note
The ID + name demo sign-in is only a front-end demonstration and is not authentication. It must never be used to expose real student records. For a real deployment, turn demo mode off and use Firebase Authentication accounts linked to each student record (`authUid`). Teacher accounts must have the `teacher: true` custom claim. Firestore client access is denied; data reads/writes go through role-checked Cloud Functions.

## Setup
1. Create a Firebase project and enable **Authentication (Email/Password)**, **Cloud Firestore**, **Cloud Functions**, and **Hosting**.
2. Copy `.env.example` to `.env` and fill in the Firebase web app configuration.
3. Install frontend dependencies: `npm install`.
4. Install function dependencies: `cd functions && npm install && cd ..`.
5. Deploy Firestore rules: `firebase deploy --only firestore:rules`.
6. Create Firebase Auth users for each student. The seed script expects emails like `s240566@students.demo`. Create these accounts with temporary passwords, then map their UIDs to student docs.
7. Set `GOOGLE_APPLICATION_CREDENTIALS` to a secure Firebase Admin service-account JSON path and run `npm run seed`. Never commit the service-account JSON.
8. Create a teacher Firebase Auth user and grant the custom claim: `npm run set-teacher -- teacher@example.com`.
9. Set the Gemini API key as a Functions secret: `firebase functions:secrets:set GEMINI_API_KEY`.
10. Deploy functions and hosting: `firebase deploy`.
11. Run locally: `npm run dev`.

## Demo mode
Set `VITE_ENABLE_DEMO_LOGIN=true` to try the sample ID/name UI without Firebase. This is an in-memory UI demonstration and does not persist attendance. For production set it to `false`, configure Firebase Auth and deploy the backend.

## Data model
`students/{studentId}`: student profile and `authUid`.
`students/{studentId}/attendance/{subjectId}`: `subjectName`, `total`, `attended`, `missed`.
`students/{studentId}/sessions/{studentId_subjectId_YYYY-MM-DD}`: one attendance event per class date.

## Production checklist
- Use institution-managed email/password, SSO or OTP; do not use ID + name as a credential.
- Add administrator-controlled user provisioning and password reset.
- Validate teacher's subject/section assignment in `markAttendance`, not just the global teacher claim.
- Use a unique class-session ID instead of date if a subject can have multiple periods per day.
- Add audit logs, backups, App Check, rate limiting, and institution privacy review.
- Consider server-side pagination and audit history for larger colleges.
